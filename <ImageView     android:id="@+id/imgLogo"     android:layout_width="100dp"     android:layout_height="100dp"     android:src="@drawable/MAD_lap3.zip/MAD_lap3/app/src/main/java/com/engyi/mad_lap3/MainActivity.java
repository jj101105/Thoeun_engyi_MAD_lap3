package com.engyi.mad_lap3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static final int REQ_ADD_EXPENSE = 1001;
    public static final String KEY_AMOUNT = "key_amount";
    public static final String KEY_CURRENCY = "key_currency";
    public static final String KEY_CATEGORY = "key_category";
    public static final String KEY_REMARK = "key_remark";
    public static final String KEY_CREATED_DATE = "key_created_date";

    // UI
    TextView tvTitle;
    TextView tvLastExpense;
    Button btnAddNew;
    Button btnViewDetail;

    String lastAmount = "0";
    String lastCurrency = "";
    String lastCategory = "";
    String lastRemark = "";
    String lastCreatedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find views
        tvTitle = findViewById(R.id.tvTitle);
        tvLastExpense = findViewById(R.id.tvLastExpense);
        btnAddNew = findViewById(R.id.btnAddNew);
        btnViewDetail = findViewById(R.id.btnViewDetail);

        // Replace [Your Name] per lab requirement
        tvTitle.setText("Manage Your Expense, Thoeun Engyi");

        // initial state
        updateLastExpenseText();
        btnViewDetail.setEnabled(false); // disable until first expense added

        btnAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // start AddExpenseActivity for result
                Intent intent = new Intent(MainActivity.this, AddExpenseActivity.class);
                startActivityForResult(intent, REQ_ADD_EXPENSE);
            }
        });

        btnViewDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open ExpenseDetailActivity and pass last saved data
                Intent intent = new Intent(MainActivity.this, ExpenseDetailActivity.class);
                intent.putExtra(KEY_AMOUNT, lastAmount);
                intent.putExtra(KEY_CURRENCY, lastCurrency);
                intent.putExtra(KEY_CATEGORY, lastCategory);
                intent.putExtra(KEY_REMARK, lastRemark);
                intent.putExtra(KEY_CREATED_DATE, lastCreatedDate);
                startActivity(intent);
            }
        });
    }

    private void updateLastExpenseText() {
        if (lastAmount == null || lastAmount.isEmpty() || lastAmount.equals("0")) {
            tvLastExpense.setText("My last expense was 0");
        } else {
            String currencyText = (lastCurrency == null || lastCurrency.isEmpty()) ? "" : " " + lastCurrency;
            tvLastExpense.setText("My last expense was " + lastAmount + currencyText);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_ADD_EXPENSE && resultCode == RESULT_OK && data != null) {
            // read data from AddExpenseActivity
            lastAmount = data.getStringExtra(KEY_AMOUNT);
            lastCurrency = data.getStringExtra(KEY_CURRENCY);
            lastCategory = data.getStringExtra(KEY_CATEGORY);
            lastRemark = data.getStringExtra(KEY_REMARK);
            lastCreatedDate = data.getStringExtra(KEY_CREATED_DATE);

            updateLastExpenseText();
            btnViewDetail.setEnabled(true);
        }
    }
}
